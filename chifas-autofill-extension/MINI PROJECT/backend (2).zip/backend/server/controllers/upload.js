const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");
exports.upload= async (req, res ) => {
    try {
      const formData = new FormData();
  
      formData.append(
        "aadhaar",
        fs.createReadStream(req.files["aadhaar"][0].path)
      );
  
      formData.append(
        "memo",
        fs.createReadStream(req.files["memo"][0].path)
      );
  
      const response = await axios.post(
        "http://localhost:5001/upload",
        formData,
        { headers: formData.getHeaders() }
      );
  
      res.json(response.data);
  
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Flask server error" });
    }
  }