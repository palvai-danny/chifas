const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs");

exports.runOCR = async (req, res) => {
  try {
    const formData = new FormData();
    formData.append("file", fs.createReadStream(req.file.path));

    const response = await axios.post(
      "http://localhost:5000/ocr",
      formData,
      { headers: formData.getHeaders() }
    );

    res.json({
      extractedText: response.data.text
    });
  } catch (err) {
    res.status(500).json({ error: "OCR failed" });
  }
};
