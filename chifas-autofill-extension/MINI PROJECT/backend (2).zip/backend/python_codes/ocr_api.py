from flask import Flask, request, jsonify
import pytesseract
from PIL import Image
import os

app = Flask(__name__)

@app.route("/ocr", methods=["POST"])
def ocr():
    file = request.files["file"]
    file_path = "temp.png"
    file.save(file_path)

    text = pytesseract.image_to_string(Image.open(file_path))
    os.remove(file_path)

    return jsonify({
        "text": text
    })

if __name__ == "__main__":
    app.run(port=5000)
