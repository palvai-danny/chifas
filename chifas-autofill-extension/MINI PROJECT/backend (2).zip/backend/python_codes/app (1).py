from flask import Flask, render_template, request, jsonify
import pytesseract, cv2, fitz, os, re, numpy as np
from PIL import Image

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def pdf_to_text(pdf_path):

    doc = fitz.open(pdf_path)
    page = doc.load_page(0)     # first page
    pix = page.get_pixmap(dpi=300)

    img = np.frombuffer(pix.samples, dtype=np.uint8)
    img = img.reshape(pix.height, pix.width, pix.n)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    text = pytesseract.image_to_string(gray)
    return text
def extract_aadhaar_number(text):

    text = text.replace("O","0").replace("I","1").replace("l","1") \
               .replace("B","8").replace("Z","2").replace("S","5")

    numbers = re.findall(r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b', text)

    if numbers:
        return numbers[0].replace("-", " ")

    return ""
    
def extract_dob(text):

    m = re.search(r'\bDOB\s*[:\-]?\s*(\d{2}[/-]\d{2}[/-]\d{4})', text, re.I)
    if m:
        return m.group(1)
    return ""
    
def extract_gender(text):

    if re.search(r'\bMALE\b', text, re.I):
        return "Male"
    if re.search(r'\bFEMALE\b', text, re.I):
        return "Female"

    return ""

import re

def extract_student_and_parents(text):

    lines = [l.strip() for l in text.split("\n") if l.strip()]

    REMOVE_WORDS = [
        "SHRI","SMT","SRI","SHREE",
        "SON OF","DAUGHTER OF","S/O","D/O",
        "FATHER'S NAME","MOTHER S NAME",
        "NAME","WAME","IFIED THAT"
    ]

    # ---------------- HELPERS ----------------

    def clean_line(line):
        line = re.sub(r'[^A-Za-z ]',' ',line)
        line = re.sub(r'\s+',' ',line).strip()
        return line

    def remove_titles(name):
        name = name.upper()
        for w in REMOVE_WORDS:
            name = name.replace(w, "")
        return name.title().strip()

    def mostly_caps(line):
        letters = sum(c.isupper() for c in line)
        total = sum(c.isalpha() for c in line)
        return total > 0 and (letters/total) > 0.6

    # ----------------------------------------

    student = ""
    father = ""
    mother = ""

    student_index = -1   # ⭐ IMPORTANT FIX

    # ========== STUDENT (ICSE) ==========
    for i,line in enumerate(lines):
        if line.upper().startswith("NAME") or line.upper().startswith("WAME"):
            part = line.split(" ",1)[1]
            student = remove_titles(clean_line(part))
            student_index = i
            break

    # ========== STUDENT (SSC) ==========
    if not student:
        for i,line in enumerate(lines):
            if "REGULAR" in line.upper():
                for j in range(i+1, min(i+10,len(lines))):
                    if mostly_caps(lines[j]):
                        student = remove_titles(clean_line(lines[j]))
                        student_index = j
                        break
                break

    # =================================================
    # ========== PARENTS METHOD 1 : ICSE ==========
    # =================================================

    for i,line in enumerate(lines):
        if "DAUGHTER OF" in line.upper() or "SON OF" in line.upper():

            if i+1 < len(lines):
                mother = remove_titles(clean_line(lines[i+1]))

            if i+2 < len(lines):
                father = remove_titles(clean_line(lines[i+2]))

            break

    # =================================================
    # ========== PARENTS METHOD 2 : SSC ==========
    # =================================================

    if (not father or not mother) and student_index != -1:

        parent_candidates = []

        for k in range(student_index+1, min(student_index+10,len(lines))):

            if mostly_caps(lines[k]):
                parent_candidates.append(lines[k])

        if len(parent_candidates) >= 1:
            father = remove_titles(clean_line(parent_candidates[0]))

        if len(parent_candidates) >= 2:
            mother = remove_titles(clean_line(parent_candidates[1]))

    # =================================================

    if not student:
        student = "NOT FOUND"
    if not father:
        father = "NOT FOUND"
    if not mother:
        mother = "NOT FOUND"

    return student, father, mother

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():

    aadhaar = request.files["aadhaar"]
    memo = request.files["memo"]

    a_path = os.path.join(UPLOAD_FOLDER, aadhaar.filename)
    m_path = os.path.join(UPLOAD_FOLDER, memo.filename)

    aadhaar.save(a_path)
    memo.save(m_path)

    a_text = pdf_to_text(a_path) if a_path.lower().endswith(".pdf") else image_to_text(a_path)
    m_text = pdf_to_text(m_path)

    a_data = extract_aadhaar_details(a_text)
    name = extract_name_from_memo(m_text)

    return jsonify({
        "name": name,
        "dob": a_data["dob"],
        "gender": a_data["gender"],
        "aadhaar": a_data["aadhaar"]
    })

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
